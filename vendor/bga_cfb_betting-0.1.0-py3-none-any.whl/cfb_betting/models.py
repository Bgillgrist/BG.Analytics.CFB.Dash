"""Chronological model evaluation and portable JSON artifacts (no pickle)."""

from __future__ import annotations

import hashlib
import json
from importlib.metadata import version

import numpy as np
import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import brier_score_loss, log_loss, mean_absolute_error

from .domain import MODELS, classify_quote, spread_probabilities, utc
from .features import FEATURE_VERSION, feature_columns, frame_hash, training_rows

MODEL_VERSION = "xgb_betting_2026_v1"
PARAMS = dict(n_estimators=500, max_depth=3, learning_rate=.03, subsample=.8,
              colsample_bytree=.8, min_child_weight=5, random_state=42, n_jobs=1)
MIN_TRAIN = 100
MIN_CALIBRATION = 50


def dependencies():
    return {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "xgboost")}


def fit_pair(frame, columns):
    from xgboost import XGBClassifier, XGBRegressor
    if len(frame) < MIN_TRAIN or frame.win_target.nunique() < 2:
        raise ValueError("Insufficient completed games for chronological training")
    classifier = XGBClassifier(**PARAMS, objective="binary:logistic", eval_metric="logloss")
    regressor = XGBRegressor(**PARAMS, objective="reg:squarederror")
    classifier.fit(frame[columns], frame.win_target.astype(int))
    regressor.fit(frame[columns], frame.margin_target)
    return classifier, regressor


def fit_calibrator(oof):
    if len(oof) < MIN_CALIBRATION or oof.target.nunique() < 2:
        raise ValueError("Insufficient prior out-of-sample predictions for calibration")
    raw = np.clip(oof.raw_probability.to_numpy(), 1e-6, 1-1e-6)
    model = LogisticRegression(C=1.0, random_state=42)
    model.fit(np.log(raw/(1-raw)).reshape(-1, 1), oof.target.astype(int))
    return {"slope": float(model.coef_[0, 0]), "intercept": float(model.intercept_[0])}


def calibrated(raw, calibrator):
    raw = np.clip(np.asarray(raw), 1e-6, 1-1e-6)
    values = calibrator["slope"] * np.log(raw/(1-raw)) + calibrator["intercept"]
    return 1 / (1 + np.exp(-np.clip(values, -50, 50)))


def reliability(probabilities, targets):
    rows = []
    for low in np.arange(0, 1, .1):
        chosen = (probabilities >= low) & (probabilities < low+.1 + (1e-9 if low > .89 else 0))
        if chosen.any():
            rows.append(dict(bin_start=round(float(low), 1), count=int(chosen.sum()),
                             predicted=float(probabilities[chosen].mean()), actual=float(targets[chosen].mean())))
    return rows


def train_bundle(frame, as_of, progress=lambda message: None, cache_get=None, cache_put=None):
    """Expanding yearly folds; first fold warms calibration, later folds are held out.

    At most four latest seasons are evaluated per run. Training always includes all
    earlier available seasons. Fold predictions can be cached by complete input hashes;
    production models are freshly fitted on every explicit training run.
    """
    train = training_rows(frame, as_of)
    bundle = dict(version=MODEL_VERSION, feature_version=FEATURE_VERSION, trained_at=utc().isoformat(),
                  cutoff=utc(as_of).isoformat(), dependencies=dependencies(), models={})
    all_metrics = {}
    for name in MODELS:
        columns = feature_columns(name)
        data = train.dropna(subset=["avg_spread"]) if name.startswith("spread") else train
        seasons = sorted(data.season.astype(int).unique())
        if len(seasons) < 3:
            raise ValueError("At least three seasons are required for training, calibration, and evaluation")
        folds = seasons[max(1, len(seasons)-4):]
        prior_oof, evaluated = [], []
        for season in folds:
            before, holdout = data.loc[data.season < season], data.loc[data.season == season]
            if len(before) < MIN_TRAIN or holdout.empty:
                continue
            progress(f"{MODELS[name]}: validating {season} using earlier seasons")
            fingerprint = frame_hash(pd.concat([before, holdout])[["game_id", "season", "kickoff", "win_target", "margin_target", *columns]])
            key = hashlib.sha256(json.dumps([MODEL_VERSION, FEATURE_VERSION, dependencies(), PARAMS, name, int(season), fingerprint], sort_keys=True).encode()).hexdigest()
            cached = cache_get(key) if cache_get else None
            if cached is not None:
                fold = pd.DataFrame(cached)
            else:
                classifier, regressor = fit_pair(before, columns)
                fold = pd.DataFrame(dict(game_id=holdout.game_id.to_numpy(), season=int(season),
                                         raw_probability=classifier.predict_proba(holdout[columns])[:, 1],
                                         predicted_margin=regressor.predict(holdout[columns]),
                                         target=holdout.win_target.to_numpy(), margin=holdout.margin_target.to_numpy(),
                                         spread=holdout.avg_spread.to_numpy()))
                if cache_put:
                    cache_put(key, json.loads(fold.to_json(orient="records")))
            if prior_oof:
                earlier = pd.concat(prior_oof, ignore_index=True)
                if len(earlier) >= MIN_CALIBRATION and earlier.target.nunique() == 2:
                    calibration = fit_calibrator(earlier)
                    fold = fold.copy()
                    fold["probability"] = calibrated(fold.raw_probability, calibration)
                    residuals = (earlier.margin - earlier.predicted_margin).to_numpy()
                    cover = []
                    for row in fold.itertuples():
                        w, p, _ = spread_probabilities(row.predicted_margin, residuals, row.spread) if pd.notna(row.spread) else (np.nan, np.nan, np.nan)
                        cover.append(w/(1-p) if np.isfinite(p) and p < 1 else np.nan)
                    fold["cover_probability"] = cover
                    evaluated.append(fold)
            prior_oof.append(fold)
        if not prior_oof or not evaluated:
            raise ValueError(f"{MODELS[name]} has insufficient independent calibration/evaluation data")
        oof = pd.concat(prior_oof, ignore_index=True)
        heldout = pd.concat(evaluated, ignore_index=True)
        calibration = fit_calibrator(oof)
        progress(f"{MODELS[name]}: fitting production models on {len(data):,} pre-cutoff games")
        classifier, regressor = fit_pair(data, columns)
        probabilities, targets = heldout.probability.to_numpy(), heldout.target.to_numpy()
        cover_sample = heldout.loc[heldout.cover_probability.notna() & (heldout.margin + heldout.spread).ne(0)]
        metrics = dict(training_games=len(data), calibration_games=len(oof), evaluation_games=len(heldout),
                       evaluation_seasons=sorted(heldout.season.astype(int).unique().tolist()),
                       brier=float(brier_score_loss(targets, probabilities)),
                       log_loss=float(log_loss(targets, probabilities, labels=[0, 1])),
                       margin_mae=float(mean_absolute_error(heldout.margin, heldout.predicted_margin)),
                       reliability=reliability(probabilities, targets),
                       cover_reliability=reliability(cover_sample.cover_probability.to_numpy(), (cover_sample.margin + cover_sample.spread).gt(0).to_numpy()) if len(cover_sample) else [],
                       cover_brier=float(brier_score_loss((cover_sample.margin + cover_sample.spread).gt(0), cover_sample.cover_probability)) if len(cover_sample) else None,
                       note="Chronological holdouts; historical quote timing and source revisions are not verified.")
        bundle["models"][name] = dict(features=columns, classifier=classifier.get_booster().save_raw(raw_format="json").decode(),
                                       regressor=regressor.get_booster().save_raw(raw_format="json").decode(), calibration=calibration,
                                       residuals=(oof.margin-oof.predicted_margin).tolist())
        all_metrics[name] = metrics
    return bundle, all_metrics


def score_quotes(bundle, frame, quotes):
    from xgboost import XGBClassifier, XGBRegressor
    output = []
    if frame.empty or quotes.empty:
        return pd.DataFrame()
    metadata = frame.set_index("game_id")
    for name, artifact in bundle["models"].items():
        sample = frame.dropna(subset=["avg_spread"]) if name.startswith("spread") else frame
        if sample.empty:
            continue
        classifier, regressor = XGBClassifier(), XGBRegressor()
        classifier.load_model(bytearray(artifact["classifier"], "utf-8"))
        regressor.load_model(bytearray(artifact["regressor"], "utf-8"))
        features = artifact["features"]
        probabilities = calibrated(classifier.predict_proba(sample[features])[:, 1], artifact["calibration"])
        margins = regressor.predict(sample[features])
        predictions = dict(zip(sample.game_id, zip(probabilities, margins)))
        for quote in quotes.to_dict("records"):
            if quote["game_id"] not in predictions:
                continue
            home_probability, margin = predictions[quote["game_id"]]
            home = quote["side"] == "home"
            if quote["market"] == "moneyline":
                values = classify_quote(home_probability if home else 1-home_probability, "moneyline", american=quote["american"])
            else:
                w, p, loss = spread_probabilities(margin, artifact["residuals"], quote["handicap"] if home else -quote["handicap"])
                values = classify_quote(w if home else loss, "spread", push_probability=p)
            row = metadata.loc[quote["game_id"]]
            inputs = {key: float(row[key]) if pd.notna(row[key]) else None for key in features}
            output.append(dict(quote, **values, model=name, model_version=bundle["version"],
                               model_spread=float(-margin if home else margin),
                               team=row.home_team if home else row.away_team,
                               opponent=row.away_team if home else row.home_team,
                               conference=row.home_conference if home else row.away_conference,
                               feature_inputs=inputs, feature_cutoff=str(row.feature_cutoff),
                               home_rating_date=row.home_rating_date, away_rating_date=row.away_rating_date))
    return pd.DataFrame(output)
