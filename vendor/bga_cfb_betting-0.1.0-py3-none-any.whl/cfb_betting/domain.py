"""Pure quote, probability, recommendation, and settlement rules."""

from __future__ import annotations

import math
import numpy as np
import pandas as pd

TIER_VERSION = "probability_edge_v1"
TIERS = ["No edge", "Slight", "Moderate", "Strong", "Very strong"]
MODELS = {
    "spread": "Spread-aware",
    "teamrankings": "TeamRankings — no spread input",
    "spread_advanced": "Spread-aware + advanced stats",
    "teamrankings_advanced": "TeamRankings + advanced stats",
}
SYNTHETIC_PROVIDERS = {"consensus", "teamrankings", "numberfire", "average", "vegas", ""}


def utc(value=None):
    value = pd.Timestamp.now(tz="UTC") if value is None else pd.Timestamp(value)
    return value.tz_localize("UTC") if value.tzinfo is None else value.tz_convert("UTC")


def decimal_odds(american):
    """Invalid/missing American prices cannot become fabricated implied probabilities."""
    try:
        value = float(american)
    except (TypeError, ValueError):
        return float("nan")
    if not math.isfinite(value) or abs(value) < 100:
        return float("nan")
    return 1 + (value / 100 if value > 0 else 100 / abs(value))


def tier(edge_pp):
    if edge_pp is None or not np.isfinite(edge_pp):
        return "Unavailable"
    # Round floating arithmetic at the band boundaries, not displayed probabilities.
    edge_pp = round(float(edge_pp), 10)
    return TIERS[0 if edge_pp <= 0 else 1 if edge_pp < 2 else 2 if edge_pp < 5 else 3 if edge_pp < 10 else 4]


def spread_probabilities(home_margin, residuals, home_handicap):
    """Empirical integer margins, excluding impossible final ties in modern FBS games."""
    draws = np.rint(float(home_margin) + np.asarray(residuals, dtype=float))
    draws = draws[np.isfinite(draws) & (draws != 0)]
    if not len(draws):
        return np.nan, np.nan, np.nan
    graded = draws + float(home_handicap)
    return float(np.mean(graded > 0)), float(np.mean(graded == 0)), float(np.mean(graded < 0))


def classify_quote(probability, market, *, american=None, push_probability=0.0):
    probability, push_probability = float(probability), float(push_probability)
    if not (np.isfinite(probability) and np.isfinite(push_probability)):
        return {"classification": "Unavailable", "edge_pp": np.nan}
    if not (0 <= probability <= 1 and 0 <= push_probability < 1 and probability + push_probability <= 1 + 1e-10):
        raise ValueError("Invalid win/push probabilities")
    if market == "spread":
        compared_probability = probability / (1 - push_probability)
        baseline, expected_return = 0.5, None
    elif market == "moneyline":
        decimal = decimal_odds(american)
        if not np.isfinite(decimal):
            return {"classification": "Unavailable", "edge_pp": np.nan}
        compared_probability, baseline = probability, 1 / decimal
        expected_return = probability * decimal - 1
    else:
        raise ValueError("Only moneyline and spread markets are supported")
    edge = 100 * (compared_probability - baseline)
    return dict(probability=compared_probability, win_probability=probability,
                push_probability=push_probability, baseline=baseline, edge_pp=edge,
                classification=tier(edge), expected_return=expected_return,
                tier_version=TIER_VERSION)


def normalize_quotes(payload, game_ids):
    """Deduplicate aliases; ambiguous provider/market pairs are unavailable, not guessed."""
    game_ids = {str(identifier) for identifier in game_ids}
    rows = {}
    conflicts = set()
    aliases = {"Draft Kings": "DraftKings", "Caesars Sportsbook (Colorado)": "Caesars",
               "Caesars (Pennsylvania)": "Caesars", "William Hill (New Jersey)": "William Hill"}
    for game in payload:
        game_id = str(game.get("id", game.get("gameId", "")))
        if game_id not in game_ids:
            continue
        for line in game.get("lines") or []:
            provider = " ".join(str(line.get("provider") or "").split())
            provider = aliases.get(provider, provider)
            if provider.lower() in SYNTHETIC_PROVIDERS:
                continue
            for side in ("home", "away"):
                for market, key in (("spread", "spread"), ("moneyline", f"{side}Moneyline")):
                    try:
                        value = float(line.get(key))
                    except (ValueError, TypeError):
                        continue
                    if not np.isfinite(value):
                        continue
                    if market == "moneyline" and not np.isfinite(decimal_odds(value)):
                        continue
                    if market == "spread":
                        if not np.isclose(value * 2, round(value * 2)):
                            continue
                        value *= 1 if side == "home" else -1
                    identity = (game_id, market, side, provider)
                    row = dict(game_id=game_id, market=market, side=side, provider=provider,
                               handicap=value if market == "spread" else None,
                               american=value if market == "moneyline" else None)
                    if identity in rows and rows[identity] != row:
                        conflicts.add((game_id, market, provider))
                    rows[identity] = row
    valid = [row for row in rows.values() if (row["game_id"], row["market"], row["provider"]) not in conflicts]
    result = pd.DataFrame(valid, columns=["game_id", "market", "side", "provider", "handicap", "american"])
    result.attrs["quote_issues"] = [dict(game_id=game_id, market=market, provider=provider,
        reason="Conflicting provider quotes; both sides excluded") for game_id, market, provider in sorted(conflicts)]
    return result


def ranked(frame):
    if frame.empty:
        return frame.copy()
    valid = frame.loc[pd.to_numeric(frame.edge_pp, errors="coerce").notna()].copy()
    return valid.sort_values(["edge_pp", "game_id", "side", "provider"],
                             ascending=[False, True, True, True], kind="stable")


def recommendations(frame):
    """One side/book per game, model, and market. Applies identically live and in history."""
    if frame.empty:
        return frame.copy()
    eligible = ranked(frame).copy()
    eligible["_offer"] = pd.to_numeric(eligible.handicap, errors="coerce").where(
        eligible.market.eq("spread"), eligible.american.map(decimal_odds))
    # Empirical probabilities can tie at different spreads. Keep the better actual
    # offer before choosing a side, rather than accidentally preferring a worse book.
    offers = eligible.sort_values(["_offer", "provider"], ascending=[False, True], kind="stable")
    offers = offers.drop_duplicates(["game_id", "model", "market", "side"])
    return ranked(offers).drop_duplicates(["game_id", "model", "market"]).drop(columns="_offer").reset_index(drop=True)


def last_pregame(snapshots, candidates, games, source="live", best_only=True):
    """Select the snapshot BEFORE dropping unavailable markets, so old quotes cannot revive."""
    if snapshots.empty or games.empty:
        return pd.DataFrame()
    games = games.copy()
    games["game_id"] = games.game_id.astype(str)
    games["kickoff"] = pd.to_datetime(games.kickoff, utc=True)
    scope = snapshots.copy()
    scope["game_id"] = scope.game_id.astype(str)
    scope = scope.merge(games, on="game_id", suffixes=("", "_current"))
    scope["completed_at"] = pd.to_datetime(scope.completed_at, utc=True)
    scope["as_of"] = pd.to_datetime(scope.as_of, utc=True)
    cutoff = scope.completed_at if source == "live" else scope.as_of
    valid = scope.status.eq("success") & scope.source.eq(source) & cutoff.lt(scope.kickoff)
    if "kickoff_known" in scope:
        valid &= scope.kickoff_known.eq(True)
    chronology = ["completed_at", "as_of", "run_id"] if source == "live" else ["as_of", "completed_at", "run_id"]
    scope = scope.loc[valid].sort_values(chronology, kind="stable")
    scope = scope.drop_duplicates(["game_id"], keep="last")
    if candidates.empty or scope.empty:
        return pd.DataFrame()
    columns = [col for col in scope if col not in candidates or col in ("run_id", "game_id")]
    selected = scope[columns].merge(candidates, on=["run_id", "game_id"])
    selected["snapshot_age_hours"] = (selected.kickoff - selected.as_of).dt.total_seconds() / 3600
    return recommendations(selected) if best_only else ranked(selected)


def settle(frame):
    frame = frame.copy()
    if frame.empty:
        return frame
    for column in ("homepoints", "awaypoints"):
        frame[column] = pd.to_numeric(frame[column], errors="coerce")
    margin = frame.homepoints - frame.awaypoints
    side_margin = margin.where(frame.side.eq("home"), -margin)
    graded = side_margin + frame.handicap.fillna(0).where(frame.market.eq("spread"), 0)
    completed = frame.completed.fillna(False).eq(True) & margin.notna()
    cancelled = frame.get("cancelled", pd.Series(False, index=frame.index)).fillna(False).eq(True)
    frame["result"] = np.select([cancelled, completed & graded.gt(0), completed & graded.lt(0), completed & graded.eq(0)],
                                ["Void", "W", "L", "Push"], default="Pending")
    frame["units"] = np.nan
    ml = frame.market.eq("moneyline")
    prices = pd.to_numeric(frame.american.map(decimal_odds), errors="coerce")
    frame.loc[ml & frame.result.eq("W"), "units"] = prices.loc[ml & frame.result.eq("W")] - 1
    frame.loc[ml & frame.result.eq("L"), "units"] = -1.0
    frame.loc[ml & frame.result.isin(["Push", "Void"]), "units"] = 0.0
    return frame


def wilson(wins, decisions):
    if not decisions:
        return np.nan, np.nan
    z = 1.959963984540054
    p = wins / decisions
    middle = (p + z*z/(2*decisions)) / (1 + z*z/decisions)
    half = z * math.sqrt(p*(1-p)/decisions + z*z/(4*decisions*decisions)) / (1 + z*z/decisions)
    return middle-half, middle+half


def performance(frame, groupby=("model", "market", "classification")):
    """Actual decisions are pooled; weekly percentages are never averaged."""
    if frame.empty:
        return pd.DataFrame()
    results = []
    for keys, group in frame.groupby(list(groupby), dropna=False, sort=False):
        keys = keys if isinstance(keys, tuple) else (keys,)
        decided = group.loc[group.result.isin(["W", "L"])]
        wins, losses = int(group.result.eq("W").sum()), int(group.result.eq("L").sum())
        lower, upper = wilson(wins, wins + losses)
        ml = group.market.eq("moneyline").all()
        row = dict(zip(groupby, keys), picks=len(group), wins=wins, losses=losses,
                   pushes=int(group.result.eq("Push").sum()), pending=int(group.result.eq("Pending").sum()),
                   voids=int(group.result.eq("Void").sum()), hit_rate=wins/(wins+losses) if wins+losses else np.nan,
                   rate_lower=lower, rate_upper=upper,
                   predicted_probability=decided.probability.mean(), baseline=decided.baseline.mean(),
                   units=decided.units.sum() if ml and len(decided) else np.nan,
                   roi=decided.units.mean() if ml and len(decided) else np.nan)
        row["excess_hit_rate"] = row["hit_rate"] - row["baseline"]
        row["roi_lower"] = row["roi_upper"] = np.nan
        if ml and len(decided):
            blocks = decided.groupby(["season", "season_type", "week"]).units.agg(["sum", "count"])
            if len(blocks) >= 2:
                draws = np.random.default_rng(42).integers(0, len(blocks), size=(2000, len(blocks)))
                values = blocks["sum"].to_numpy()[draws].sum(axis=1) / blocks["count"].to_numpy()[draws].sum(axis=1)
                row["roi_lower"], row["roi_upper"] = np.quantile(values, [.025, .975])
        results.append(row)
    return pd.DataFrame(results)
