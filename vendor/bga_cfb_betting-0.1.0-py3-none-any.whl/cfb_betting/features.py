"""Pregame features built from raw game-level facts, never final season aggregates."""

from __future__ import annotations

import hashlib
import json
import numpy as np
import pandas as pd

from .domain import utc

FEATURE_VERSION = "pregame_advanced_v1"
BASE_FEATURES = ["home_teamrankings_rating", "away_teamrankings_rating", "home_talent", "away_talent", "neutral_site"]
STAT_METRICS = [f"{side}_{metric}" for side in ("offense", "defense") for metric in
                ("ppa", "successrate", "explosiveness", "passingplays_ppa", "rushingplays_ppa", "stuffrate")]
ADVANCED_FEATURES = [f"{side}_{window}_{metric}" for side in ("home", "away")
                     for window in ("season", "last5", "prior") for metric in STAT_METRICS]
ADVANCED_FEATURES += [f"{side}_{window}_games" for side in ("home", "away") for window in ("season", "last5", "prior")]


def feature_columns(model):
    return (["avg_spread"] if model.startswith("spread") else []) + BASE_FEATURES + (ADVANCED_FEATURES if model.endswith("advanced") else [])


def frame_hash(frame):
    """Stable across DB row ordering; include targets when hashing validation inputs."""
    if frame.empty:
        return hashlib.sha256(b"empty").hexdigest()
    ordered = frame.sort_values("game_id") if "game_id" in frame else frame.sort_index()
    content = ordered.reindex(sorted(ordered.columns), axis=1).to_json(orient="split", date_format="iso", double_precision=12, index=False)
    return hashlib.sha256(content.encode()).hexdigest()


def prepare_games(games):
    frame = games.copy()
    if frame.empty:
        return frame
    frame["game_id"] = frame.game_id.astype(str)
    frame["kickoff"] = pd.to_datetime(frame.kickoff, utc=True, errors="coerce")
    frame["kickoff_known"] = frame.kickoff.notna() & ~frame.starttimetbd.eq(True)
    frame["season_type"] = frame.season_type.fillna("regular").str.lower()
    frame["neutral_site"] = frame.neutralsite.fillna(False).astype(bool).astype(float)
    for column in ("homepoints", "awaypoints", "home_talent", "away_talent", "avg_spread"):
        frame[column] = pd.to_numeric(frame[column], errors="coerce") if column in frame else np.nan
    frame["margin_target"] = frame.homepoints - frame.awaypoints
    frame["win_target"] = (frame.margin_target > 0).where(frame.margin_target.notna()).astype(float)
    frame["completed"] = frame.completed.fillna(False).astype(bool)
    return frame.sort_values(["kickoff", "game_id"]).reset_index(drop=True)


def build_features(games, ratings, stats, as_of, target_ids=None):
    """Date-granularity sources conservatively exclude all games on the cutoff day.

    A future matchup's features are capped at the current analysis date, so historical
    replay cannot accidentally pick up ratings or performances between analysis and kickoff.
    """
    result = prepare_games(games)
    if result.empty:
        return result
    as_of_day = utc(as_of).tz_convert("America/New_York").normalize().tz_localize(None)
    game_days = result.kickoff.dt.tz_convert("America/New_York").dt.normalize().dt.tz_localize(None)
    result["feature_cutoff"] = game_days.clip(upper=as_of_day)
    ratings = ratings.copy()
    if not ratings.empty:
        ratings["pull_date"] = pd.to_datetime(ratings.pull_date).dt.tz_localize(None)
        ratings = ratings.sort_values("pull_date").drop_duplicates(["season", "team", "pull_date"], keep="last")
    rating_groups = {(int(season), team): group for (season, team), group in ratings.groupby(["season", "team"])} if not ratings.empty else {}

    history = stats.copy()
    if not history.empty:
        history["game_id"] = history.game_id.astype(str)
        if history.duplicated(["game_id", "team"]).any():
            raise ValueError("Duplicate advanced game statistics")
        history = history.merge(result[["game_id", "kickoff", "completed"]], on="game_id")
        history = history.loc[history.completed & history.kickoff.notna()].copy()
        history["day"] = history.kickoff.dt.tz_convert("America/New_York").dt.normalize().dt.tz_localize(None)
        for metric in STAT_METRICS:
            history[metric] = pd.to_numeric(history[metric], errors="coerce") if metric in history else np.nan
    stat_groups = {team: group.sort_values(["day", "game_id"]) for team, group in history.groupby("team")} if not history.empty else {}
    if target_ids is not None:
        result = result.loc[result.game_id.isin({str(identifier) for identifier in target_ids})].copy()
    additions = []
    for row in result.itertuples():
        extra = {}
        for side in ("home", "away"):
            team = getattr(row, f"{side}_team")
            rating = rating_groups.get((int(row.season), team))
            eligible = rating.loc[rating.pull_date < row.feature_cutoff] if rating is not None else pd.DataFrame()
            extra[f"{side}_teamrankings_rating"] = float(eligible.iloc[-1].rating) if len(eligible) else np.nan
            extra[f"{side}_rating_date"] = str(eligible.iloc[-1].pull_date.date()) if len(eligible) else None
            team_stats = stat_groups.get(team)
            past = team_stats.loc[team_stats.day < row.feature_cutoff] if team_stats is not None else pd.DataFrame()
            current = past.loc[past.season.eq(row.season)] if len(past) else past
            windows = {"season": current, "last5": current.tail(5),
                       "prior": past.loc[past.season.eq(row.season - 1)] if len(past) else past}
            for window, sample in windows.items():
                extra[f"{side}_{window}_games"] = len(sample)
                means = sample[STAT_METRICS].mean() if len(sample) else {}
                for metric in STAT_METRICS:
                    extra[f"{side}_{window}_{metric}"] = means.get(metric, np.nan)
        additions.append(extra)
    return pd.concat([result, pd.DataFrame(additions, index=result.index)], axis=1)


def training_rows(frame, as_of):
    day = utc(as_of).tz_convert("America/New_York").normalize()
    fbs = frame.homeclassification.eq("fbs") & frame.awayclassification.eq("fbs")
    return frame.loc[fbs & frame.completed & frame.kickoff.lt(day) & frame.margin_target.notna() & frame.margin_target.ne(0)].copy()


def quote_inputs(frame, quotes):
    """Never reuse yesterday's line as a feature when today's collection has none."""
    result = frame.copy()
    home_spreads = quotes.loc[quotes.market.eq("spread") & quotes.side.eq("home")]
    means = home_spreads.groupby("game_id").handicap.mean() if len(home_spreads) else pd.Series(dtype=float)
    result["avg_spread"] = result.game_id.map(means)
    return result
