"""Explicit training/refresh entrypoints. Nothing runs on a dashboard read."""

from __future__ import annotations

import hashlib
import uuid

import pandas as pd
import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

from . import store
from .domain import normalize_quotes, utc
from .features import build_features, frame_hash, prepare_games, quote_inputs, training_rows
from .models import MODEL_VERSION, train_bundle, score_quotes


def fetch_odds(config, season, game_ids, progress=lambda message: None):
    if not config.api_key:
        raise ValueError("Set CFBD_API_KEY in Streamlit secrets or the environment before refreshing odds")
    session = requests.Session()
    session.headers.update({"Authorization": f"Bearer {config.api_key}", "Accept": "application/json"})
    retries = Retry(total=3, backoff_factor=1, status_forcelist=[429, 500, 502, 503, 504], allowed_methods=["GET"])
    session.mount("https://", HTTPAdapter(max_retries=retries))
    payload = []
    try:
        for season_type in ("regular", "postseason"):
            progress(f"Retrieving CFBD {season_type} odds")
            response = session.get("https://api.collegefootballdata.com/lines",
                                   params={"year": int(season), "seasonType": season_type}, timeout=(15, 90))
            if response.status_code != 200:
                raise RuntimeError(f"CFBD odds request failed (HTTP {response.status_code}); saved results are unchanged")
            body = response.json()
            if not isinstance(body, list):
                raise ValueError("CFBD returned an unexpected odds response")
            payload.extend(body)
    finally:
        session.close()
    return normalize_quotes(payload, game_ids), utc()


def upcoming(frame, season, as_of):
    return frame.loc[frame.season.eq(season) & frame.homeclassification.eq("fbs") & frame.awayclassification.eq("fbs")
                     & frame.kickoff_known & ~frame.completed & ~frame.cancelled.fillna(False)
                     & frame.kickoff.gt(utc(as_of))].copy()


def run_analysis(config, season, *, retrain=True, progress=lambda message: None):
    """All writes commit together. Overlapping requests share a transaction-level lock."""
    if not config.api_key:
        raise ValueError("Set CFBD_API_KEY in Streamlit secrets or the environment before running analysis")
    store.initialize(config)
    run_id, as_of = str(uuid.uuid4()), utc()
    action = "train" if retrain else "refresh"
    try:
        with store.analysis_transaction(config, season, "live") as conn:
            saved = None if retrain else store.latest_model(conn, season)
            if saved is not None and saved["artifact"]["version"] != MODEL_VERSION:
                raise ValueError("Saved models use an older version. Use Run analysis to train the current version.")
            progress("Loading games, dated TeamRankings ratings, and advanced game stats")
            games, ratings, stats = store.load_inputs(conn, season)
            eligible = upcoming(prepare_games(games), season, utc())
            if eligible.empty:
                raise ValueError("There are no upcoming FBS-vs-FBS games with confirmed kickoff times in this season")
            quotes, as_of = fetch_odds(config, season, eligible.game_id, progress)
            issues = quotes.attrs.get("quote_issues", [])
            if issues:
                progress(f"Excluded {len(issues)} ambiguous sportsbook markets; other verified quotes remain available")
            progress("Building features from prior completed games")
            frame = build_features(games, ratings, stats, as_of,
                                   target_ids=None if retrain else eligible.game_id)
            targets = quote_inputs(upcoming(frame, season, as_of), quotes)
            targets["quote_issues"] = targets.game_id.map(lambda game_id: [item for item in issues if item["game_id"] == game_id])
            quotes = quotes.loc[quotes.game_id.isin(targets.game_id)].copy()
            if targets.empty:
                raise ValueError("There are no upcoming FBS-vs-FBS games with confirmed kickoff times in this season")
            data_hash = frame_hash(training_rows(frame, as_of)) if retrain else saved["data_hash"]
            if retrain:
                bundle, metrics = train_bundle(frame, as_of, progress,
                    cache_get=lambda key: store.cache_get(conn, key),
                    cache_put=lambda key, data: store.cache_put(conn, key, data))
                model_id = store.save_model(conn, season, "live", bundle, metrics, data_hash)
            else:
                bundle, metrics, model_id = saved["artifact"], saved["metrics"], str(saved["model_id"])
            progress("Scoring every available side and sportsbook with all four models")
            predictions = score_quotes(bundle, targets, quotes)
            store.save_snapshot(conn, run_id=run_id, season=season, source="live", action=action,
                as_of=as_of.to_pydatetime(), model_id=model_id, games=targets, quotes=quotes,
                predictions=predictions, data_hash=hashlib.sha256((data_hash+frame_hash(targets)+frame_hash(quotes)).encode()).hexdigest())
        return dict(run_id=run_id, games=len(targets), quotes=len(quotes), classifications=len(predictions), metrics=metrics)
    except Exception as exc:
        # Store only safe summaries; connection exceptions can include deployment details.
        message = str(exc) if isinstance(exc, ValueError) else f"{type(exc).__name__}: analysis did not complete"
        try:
            store.record_failure(config, run_id, season, "live", action, as_of.to_pydatetime(), message)
        except Exception:
            pass  # Preserve the original actionable error if persistence is unavailable.
        raise


def backtest(config, seasons=(2023, 2024, 2025), progress=print, max_weeks=None):
    """Research only: weekly model refits, one date-specific classification per game.

    Historical quotes have unknown timing. Features are reconstructed for each game
    date; the weekly model is trained before that week's first game. Each model/week
    plus its daily snapshots commit atomically and can be resumed by input hash.
    """
    store.initialize(config)
    processed = 0
    for season in seasons:
        with store.connect(config) as conn:
            games, ratings, stats = store.load_inputs(conn, int(season))
            horizon = pd.Timestamp(year=int(season)+1, month=4, day=1, tz="UTC")
            frame = build_features(games, ratings, stats, horizon)
            eligible = frame.loc[frame.season.eq(season) & frame.homeclassification.eq("fbs") & frame.awayclassification.eq("fbs")
                                 & frame.completed & frame.kickoff_known & frame.margin_target.notna()].copy()
            payload = store.load_historical_quotes(conn, eligible.game_id.tolist())
        quotes = normalize_quotes(payload, eligible.game_id)
        grouped = list(eligible.groupby(["season_type", "week"]))
        grouped.sort(key=lambda item: item[1].kickoff.min())
        for (season_type, week), week_games in grouped:
            if max_weeks is not None and processed >= max_weeks:
                return processed
            cutoff = week_games.kickoff.min().tz_convert("America/New_York").normalize().tz_convert("UTC")
            # All training features are already capped at their own historical game date.
            data_hash = frame_hash(training_rows(frame, cutoff))
            week_quotes = quotes.loc[quotes.game_id.isin(week_games.game_id)]
            run_hash = hashlib.sha256((MODEL_VERSION+data_hash+frame_hash(week_games)+frame_hash(week_quotes)).encode()).hexdigest()
            with store.analysis_transaction(config, season, "research") as conn:
                existing = conn.execute("SELECT 1 FROM public.betting_analysis_runs WHERE source='research' AND status='success' AND data_hash=%s LIMIT 1", (run_hash,)).fetchone()
                if existing:
                    progress(f"{season} {season_type} week {week}: already saved")
                    continue
                progress(f"Backtesting {season} {season_type} week {week}")
                bundle, metrics = train_bundle(frame, cutoff, progress,
                    cache_get=lambda key: store.cache_get(conn, key),
                    cache_put=lambda key, data: store.cache_put(conn, key, data))
                model_id = store.save_model(conn, season, "research", bundle, metrics, data_hash)
                days = week_games.kickoff.dt.tz_convert("America/New_York").dt.normalize()
                for day, targets in week_games.groupby(days):
                    day_quotes = week_quotes.loc[week_quotes.game_id.isin(targets.game_id)]
                    targets = quote_inputs(targets, day_quotes)
                    targets["quote_issues"] = targets.game_id.map(lambda game_id: [item for item in quotes.attrs.get("quote_issues", []) if item["game_id"] == game_id])
                    predictions = score_quotes(bundle, targets, day_quotes)
                    store.save_snapshot(conn, run_id=str(uuid.uuid4()), season=season, source="research", action="backtest",
                        as_of=day.to_pydatetime(), model_id=model_id, games=targets, quotes=day_quotes,
                        predictions=predictions, data_hash=run_hash)
            processed += 1
    return processed
