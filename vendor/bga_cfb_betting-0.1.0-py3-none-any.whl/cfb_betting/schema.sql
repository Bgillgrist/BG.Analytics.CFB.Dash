-- Additive schema. Predictions/quotes are insert-only; outcomes have a separate audit.
CREATE TABLE IF NOT EXISTS public.betting_model_bundles (
    model_id UUID PRIMARY KEY, season INT NOT NULL, source TEXT NOT NULL,
    trained_at TIMESTAMPTZ NOT NULL, cutoff TIMESTAMPTZ NOT NULL,
    model_version TEXT NOT NULL, data_hash TEXT NOT NULL,
    artifact JSONB NOT NULL, metrics JSONB NOT NULL
);
CREATE TABLE IF NOT EXISTS public.betting_analysis_runs (
    run_id UUID PRIMARY KEY, season INT NOT NULL,
    source TEXT NOT NULL CHECK (source IN ('live', 'research')),
    action TEXT NOT NULL, model_id UUID REFERENCES public.betting_model_bundles(model_id),
    as_of TIMESTAMPTZ NOT NULL, created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    completed_at TIMESTAMPTZ, status TEXT NOT NULL CHECK (status IN ('running', 'success', 'failed')),
    tier_version TEXT NOT NULL, data_hash TEXT, error_message TEXT
);
CREATE INDEX IF NOT EXISTS betting_runs_lookup ON public.betting_analysis_runs (season, source, completed_at DESC);
CREATE TABLE IF NOT EXISTS public.betting_run_games (
    run_id UUID NOT NULL REFERENCES public.betting_analysis_runs(run_id),
    game_id TEXT NOT NULL, metadata JSONB NOT NULL,
    PRIMARY KEY (run_id, game_id)
);
CREATE INDEX IF NOT EXISTS betting_games_lookup ON public.betting_run_games (game_id, run_id);
CREATE TABLE IF NOT EXISTS public.betting_odds_snapshots (
    run_id UUID NOT NULL REFERENCES public.betting_analysis_runs(run_id),
    game_id TEXT NOT NULL, market TEXT NOT NULL, side TEXT NOT NULL, provider TEXT NOT NULL,
    handicap DOUBLE PRECISION, american DOUBLE PRECISION,
    PRIMARY KEY (run_id, game_id, market, side, provider),
    FOREIGN KEY (run_id, game_id) REFERENCES public.betting_run_games(run_id, game_id)
);
CREATE TABLE IF NOT EXISTS public.betting_classifications (
    run_id UUID NOT NULL, game_id TEXT NOT NULL, market TEXT NOT NULL,
    side TEXT NOT NULL, provider TEXT NOT NULL, model TEXT NOT NULL, prediction JSONB NOT NULL,
    PRIMARY KEY (run_id, game_id, market, side, provider, model),
    FOREIGN KEY (run_id, game_id, market, side, provider)
      REFERENCES public.betting_odds_snapshots(run_id, game_id, market, side, provider)
);
CREATE TABLE IF NOT EXISTS public.betting_validation_cache (
    cache_key TEXT PRIMARY KEY, predictions JSONB NOT NULL, created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE TABLE IF NOT EXISTS public.betting_outcome_audit (
    outcome_id BIGSERIAL PRIMARY KEY, game_id TEXT NOT NULL,
    observed_at TIMESTAMPTZ NOT NULL DEFAULT NOW(), homepoints DOUBLE PRECISION,
    awaypoints DOUBLE PRECISION, completed BOOLEAN NOT NULL, cancelled BOOLEAN NOT NULL DEFAULT FALSE,
    source TEXT NOT NULL DEFAULT 'game_data'
);
CREATE INDEX IF NOT EXISTS betting_outcomes_lookup ON public.betting_outcome_audit (game_id, outcome_id DESC);
