"""Explicit commands; no schedules or automatic refresh side effects."""

import argparse
import os

from .service import backtest, run_analysis
from .store import Config, initialize


def main():
    parser = argparse.ArgumentParser(description="BG Analytics betting engine")
    commands = parser.add_subparsers(dest="command", required=True)
    commands.add_parser("init-db", help="Create additive betting tables")
    for command in ("train", "refresh"):
        sub = commands.add_parser(command)
        sub.add_argument("--season", type=int, required=True)
    sub = commands.add_parser("backtest", help="Save research simulations, separate from live history")
    sub.add_argument("--seasons", nargs="+", type=int, default=[2023, 2024, 2025])
    sub.add_argument("--max-weeks", type=int, help="Optional bounded smoke run; normal runs resume completed weeks")
    args = parser.parse_args()
    dsn = os.getenv("PG_DSN") or os.getenv("NEON_DATABASE_URL")
    if not dsn:
        parser.error("Set PG_DSN or NEON_DATABASE_URL")
    config = Config(dsn, os.getenv("CFBD_API_KEY"))
    if args.command == "init-db":
        initialize(config)
    elif args.command == "backtest":
        print(f"Saved {backtest(config, args.seasons, max_weeks=args.max_weeks)} research weeks")
    else:
        result = run_analysis(config, args.season, retrain=args.command == "train", progress=print)
        print(f"Saved {result['classifications']} classifications in run {result['run_id']}")


if __name__ == "__main__":
    main()
