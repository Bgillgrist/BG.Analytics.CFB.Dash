"""Shared betting engine. Importing the package never connects or trains."""

__version__ = "0.1.0"
