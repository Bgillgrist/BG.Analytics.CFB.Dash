"""Postgres persistence shared by the dashboard and CLI. No connection at import."""

from __future__ import annotations

from contextlib import contextmanager
from dataclasses import dataclass, field
from importlib.resources import files
import json
import uuid

import pandas as pd
import psycopg
from psycopg.rows import dict_row
from psycopg.types.json import Jsonb

from .domain import TIER_VERSION, utc
from .features import STAT_METRICS


@dataclass(frozen=True)
class Config:
    dsn: str = field(repr=False)
    api_key: str | None = field(default=None, repr=False)


def normalized_dsn(dsn):
    return dsn.replace("postgresql+psycopg://", "postgresql://", 1).replace("postgresql+psycopg2://", "postgresql://", 1)


def connect(config):
    return psycopg.connect(normalized_dsn(config.dsn), connect_timeout=15, row_factory=dict_row)


def records(frame):
    return json.loads(frame.to_json(orient="records", date_format="iso"))


def clean(value):
    return json.loads(pd.Series([value]).to_json(orient="values", date_format="iso"))[0]


def query(conn, sql, params=None):
    cursor = conn.execute(sql, params)
    return pd.DataFrame(cursor.fetchall(), columns=[col.name for col in cursor.description])


def schema_available(conn):
    row = conn.execute("SELECT to_regclass('public.betting_analysis_runs') AS name").fetchone()
    return bool(row["name"] if isinstance(row, dict) else row[0])


def initialize(config):
    with connect(config) as conn:
        conn.execute(files("cfb_betting").joinpath("schema.sql").read_text())


@contextmanager
def analysis_transaction(config, season, source):
    """Transaction advisory lock works with Neon/PgBouncer transaction pooling."""
    with connect(config) as conn:
        key = f"cfb_betting:{season}:{source}"
        locked = conn.execute("SELECT pg_try_advisory_xact_lock(hashtextextended(%s, 0)) AS locked", (key,)).fetchone()["locked"]
        if not locked:
            raise RuntimeError("An analysis for this season is already running. Try again after it finishes.")
        yield conn


def load_inputs(conn, season):
    games = query(conn, """
        SELECT g.id::text AS game_id, g.season, g.week,
               LOWER(COALESCE(g.seasontype,'regular')) AS season_type,
               g.startdate AS kickoff, g.starttimetbd, g.completed, g.neutralsite,
               (g.completed IS NOT TRUE AND LOWER(BTRIM(COALESCE(g.notes,''))) ~ '^(game )?cancel(l)?ed([ .:-]|$)') AS cancelled,
               g.hometeam AS home_team, g.awayteam AS away_team,
               g.homeconference AS home_conference, g.awayconference AS away_conference,
               LOWER(g.homeclassification) AS homeclassification,
               LOWER(g.awayclassification) AS awayclassification,
               g.homepoints, g.awaypoints, ht.talent AS home_talent, at.talent AS away_talent,
               o.avg_spread
        FROM public.game_data g
        LEFT JOIN public.team_talent_composite ht ON ht.team=g.hometeam AND ht.year=g.season
        LEFT JOIN public.team_talent_composite at ON at.team=g.awayteam AND at.year=g.season
        LEFT JOIN (
            SELECT "Id" AS id, AVG("Spread") AS avg_spread FROM public.betting_odds
            WHERE LOWER(COALESCE("LineProvider",'')) NOT IN ('','consensus','teamrankings','numberfire','average','vegas')
            GROUP BY "Id"
        ) o ON o.id=g.id
        WHERE g.season BETWEEN 2015 AND %s AND g.startdate IS NOT NULL
          AND (LOWER(g.homeclassification)='fbs' OR LOWER(g.awayclassification)='fbs')
        ORDER BY g.startdate,g.id
    """, (int(season),))
    if games.game_id.duplicated().any():
        raise ValueError("Game/talent joins produced duplicate games")
    ratings = query(conn, "SELECT season, team, pull_date, rating FROM public.teamrankings_predictive_ratings WHERE season BETWEEN 2015 AND %s", (int(season),))
    metrics = ", ".join(STAT_METRICS)  # Closed internal list, not user input.
    stats = query(conn, f"SELECT game_id::text, season, team, {metrics} FROM public.team_advanced_game_stats WHERE season BETWEEN 2014 AND %s", (int(season),))
    return games, ratings, stats


def load_historical_quotes(conn, game_ids):
    raw = query(conn, '''SELECT "Id"::text AS game_id, "LineProvider" AS provider,
                        "Spread" AS spread, "HomeMoneyline" AS home_moneyline, "AwayMoneyline" AS away_moneyline
                        FROM public.betting_odds WHERE "Id"::text = ANY(%s)''', (list(game_ids),))
    payload = []
    for identifier, group in raw.groupby("game_id"):
        payload.append(dict(id=identifier, lines=[dict(provider=row.provider, spread=row.spread,
                     homeMoneyline=row.home_moneyline, awayMoneyline=row.away_moneyline) for row in group.itertuples()]))
    return payload


def save_model(conn, season, source, bundle, metrics, data_hash):
    model_id = str(uuid.uuid4())
    conn.execute("""INSERT INTO public.betting_model_bundles
        (model_id,season,source,trained_at,cutoff,model_version,data_hash,artifact,metrics)
        VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s)""",
        (model_id, int(season), source, bundle["trained_at"], bundle["cutoff"], bundle["version"],
         data_hash, Jsonb(clean(bundle)), Jsonb(clean(metrics))))
    return model_id


def latest_model(conn, season):
    row = conn.execute("""SELECT m.* FROM public.betting_model_bundles m
        WHERE m.season=%s AND m.source='live'
        AND EXISTS (SELECT 1 FROM public.betting_analysis_runs r WHERE r.model_id=m.model_id AND r.status='success')
        ORDER BY m.trained_at DESC, m.model_id DESC LIMIT 1""", (int(season),)).fetchone()
    if row is None:
        raise ValueError("Run analysis first to train and save models for this season")
    return row


def cache_get(conn, key):
    row = conn.execute("SELECT predictions FROM public.betting_validation_cache WHERE cache_key=%s", (key,)).fetchone()
    return row["predictions"] if row else None


def cache_put(conn, key, data):
    conn.execute("INSERT INTO public.betting_validation_cache(cache_key,predictions) VALUES(%s,%s) ON CONFLICT DO NOTHING", (key, Jsonb(data)))


def save_snapshot(conn, *, run_id, season, source, action, as_of, model_id, games, quotes, predictions, data_hash):
    conn.execute("""INSERT INTO public.betting_analysis_runs
        (run_id,season,source,action,model_id,as_of,completed_at,status,tier_version,data_hash)
        VALUES (%s,%s,%s,%s,%s,%s,NULL,'running',%s,%s)""",
        (run_id, int(season), source, action, model_id, as_of, TIER_VERSION, data_hash))
    metadata_columns = ["game_id", "season", "week", "season_type", "home_team", "away_team", "kickoff", "kickoff_known"]
    if "quote_issues" in games:
        metadata_columns.append("quote_issues")
    with conn.cursor() as cursor:
        cursor.executemany("INSERT INTO public.betting_run_games(run_id,game_id,metadata) VALUES(%s,%s,%s)",
                           [(run_id, row["game_id"], Jsonb(row)) for row in records(games[metadata_columns])])
        cursor.executemany("""INSERT INTO public.betting_odds_snapshots
            (run_id,game_id,market,side,provider,handicap,american) VALUES(%s,%s,%s,%s,%s,%s,%s)""",
            [(run_id, row["game_id"], row["market"], row["side"], row["provider"], row["handicap"], row["american"]) for row in records(quotes)])
        cursor.executemany("""INSERT INTO public.betting_classifications
            (run_id,game_id,market,side,provider,model,prediction) VALUES(%s,%s,%s,%s,%s,%s,%s)""",
            [(run_id, row["game_id"], row["market"], row["side"], row["provider"], row["model"], Jsonb(row)) for row in records(predictions)])
    audit_outcomes(conn)
    row = conn.execute("""UPDATE public.betting_analysis_runs SET status='success', completed_at=clock_timestamp()
        WHERE run_id=%s AND status='running' RETURNING completed_at""", (run_id,)).fetchone()
    return row["completed_at"]


def record_failure(config, run_id, season, source, action, as_of, message):
    with connect(config) as conn:
        conn.execute("""INSERT INTO public.betting_analysis_runs
            (run_id,season,source,action,as_of,completed_at,status,tier_version,error_message)
            VALUES(%s,%s,%s,%s,%s,NOW(),'failed',%s,%s) ON CONFLICT DO NOTHING""",
            (run_id, int(season), source, action, as_of, TIER_VERSION, message))


def audit_outcomes(conn):
    """Append only changed known outcomes. May be called by the existing game refresh."""
    if not schema_available(conn):
        return 0
    cursor = conn.execute("""
        INSERT INTO public.betting_outcome_audit(game_id,homepoints,awaypoints,completed,cancelled)
        SELECT g.id::text,g.homepoints,g.awaypoints,COALESCE(g.completed,FALSE),
               (g.completed IS NOT TRUE AND LOWER(BTRIM(COALESCE(g.notes,''))) ~ '^(game )?cancel(l)?ed([ .:-]|$)')
        FROM public.game_data g
        LEFT JOIN LATERAL (SELECT * FROM public.betting_outcome_audit a
                           WHERE a.game_id=g.id::text ORDER BY outcome_id DESC LIMIT 1) old ON TRUE
        WHERE EXISTS (SELECT 1 FROM public.betting_run_games s WHERE s.game_id=g.id::text)
          AND (old.outcome_id IS NULL OR
               (old.homepoints,old.awaypoints,old.completed,old.cancelled) IS DISTINCT FROM
               (g.homepoints,g.awaypoints,COALESCE(g.completed,FALSE),
                (g.completed IS NOT TRUE AND LOWER(BTRIM(COALESCE(g.notes,''))) ~ '^(game )?cancel(l)?ed([ .:-]|$)')))
    """)
    return cursor.rowcount


def read_seasons(config):
    with connect(config) as conn:
        return query(conn, """SELECT DISTINCT season FROM public.game_data
            WHERE LOWER(homeclassification)='fbs' AND LOWER(awayclassification)='fbs' ORDER BY season DESC""")


def read_data(config, season, source="live"):
    """Read-only page loader: no migrations, training, refreshing, or outcome writes."""
    with connect(config) as conn:
        conn.read_only = True
        games = query(conn, """SELECT id::text AS game_id, season, week,
            LOWER(COALESCE(seasontype,'regular')) AS season_type, startdate AS kickoff,
            startdate IS NOT NULL AND starttimetbd IS NOT TRUE AS kickoff_known,
            hometeam AS home_team, awayteam AS away_team, homeconference AS home_conference,
            awayconference AS away_conference, homepoints,awaypoints,completed,
            (completed IS NOT TRUE AND LOWER(BTRIM(COALESCE(notes,''))) ~ '^(game )?cancel(l)?ed([ .:-]|$)') AS cancelled
            FROM public.game_data WHERE season=%s AND LOWER(homeclassification)='fbs' AND LOWER(awayclassification)='fbs'
        """, (int(season),))
        if not schema_available(conn):
            return dict(games=games, runs=pd.DataFrame(), scopes=pd.DataFrame(), candidates=pd.DataFrame(), metrics={}, outcomes=pd.DataFrame())
        runs = query(conn, """SELECT r.*,m.trained_at,m.cutoff AS training_cutoff,m.model_version
            FROM public.betting_analysis_runs r LEFT JOIN public.betting_model_bundles m USING(model_id)
            WHERE r.season=%s AND r.source=%s ORDER BY r.completed_at,r.run_id""", (int(season), source))
        scopes = query(conn, """SELECT r.run_id::text,r.source,r.status,r.as_of,r.completed_at,s.game_id,
            COALESCE(s.metadata->'quote_issues','[]'::jsonb) AS quote_issues
            FROM public.betting_run_games s JOIN public.betting_analysis_runs r USING(run_id)
            WHERE r.season=%s AND r.source=%s AND r.status='success'""", (int(season), source))
        raw = query(conn, """SELECT c.run_id::text,c.prediction - 'feature_inputs' AS prediction FROM public.betting_classifications c
            JOIN public.betting_analysis_runs r USING(run_id)
            WHERE r.season=%s AND r.source=%s AND r.status='success'""", (int(season), source))
        candidates = pd.DataFrame([dict(row.prediction, run_id=row.run_id) for row in raw.itertuples()])
        metrics_row = conn.execute("""SELECT m.metrics FROM public.betting_analysis_runs r
            JOIN public.betting_model_bundles m USING(model_id)
            WHERE r.season=%s AND r.source=%s AND r.status='success'
            ORDER BY r.completed_at DESC,r.run_id DESC LIMIT 1""", (int(season), source)).fetchone()
        outcomes = query(conn, """SELECT a.* FROM public.betting_outcome_audit a
            JOIN public.game_data g ON g.id::text=a.game_id WHERE g.season=%s ORDER BY outcome_id""", (int(season),))
        return dict(games=games, runs=runs, scopes=scopes, candidates=candidates,
                    metrics=metrics_row["metrics"] if metrics_row else {}, outcomes=outcomes)
